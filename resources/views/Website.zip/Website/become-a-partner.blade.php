@include('Website.header')

 <section class="comman_banner">
     <div class="container">
         <div class="row align-items-center">
             <div class="col-lg-6 order-lg-0 order-md-1 order-1">
                 <div class="comman_banner_content">
                     <strong>PARTNERS PROGRAM</strong>
                     <h1>Lorem Ipsum <br> dolor sit amet</h1>
                     <div class="banner_btns mt-4">
                         <a href="#" class="comman_btns">Lorem ipsum</a>
                         <a href="#" class="comman_btns ml-3">Lorem ipsum</a>
                     </div>
                 </div>
             </div>
             <div class="col-lg-6">
                 <div class="banner_img text-center">
                     <img src="website/assets/images/documentation/ilustradeck.png" alt="">
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="partner">
     <div class="container">
         <div class="row">
             <div class="col-12 sections_header text-center mb-5">
                 <h2>Partners</h2>
             </div>
             <div class="col-12 mt-3">
                 <div class="partner_slider owl-carousel">
                     <div class="partner_logo">
                         <span class="circle_box">
                             <img src="website/assets/images/client_logo/logo3.png" alt="">
                         </span>
                     </div>
                     <div class="partner_logo">
                         <span class="circle_box">
                             <img src="website/assets/images/client_logo/logo4.png" alt="">
                         </span>
                     </div>
                     <div class="partner_logo">
                         <span class="circle_box">
                             <img src="website/assets/images/client_logo/logo5.png" alt="">
                         </span>
                     </div>
                     <div class="partner_logo">
                         <span class="circle_box">
                             <img src="website/assets/images/client_logo/logo6.png" alt="">
                         </span>
                     </div>
                     <div class="partner_logo">
                         <span class="circle_box">
                             <img src="website/assets/images/client_logo/logo7.png" alt="">
                         </span>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="benefits_advantages">
     <div class="container py-md-5 pb-5 pt-4">
         <div class="row justify-content-center">
             <div class="col-md-8 header_advantages text-center mb-5 mt-lg-4">
                 <h2>The Future of Investing</h2>
                 <p>An opportunity for every person with an idea, a brand with a following, and every cause with a purpose. </p>
             </div>
         </div>
         <div class="row justify-content-center">
             <div class="col-lg-10">
                 <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                     <div class="col-md-auto">
                         <div class="benefits_img">
                             <img src="website/assets/images/become-a-ptb/Icon-1.png" alt="">
                         </div>
                     </div>
                     <div class="col">
                         <div class="benefits_box_content">
                             <h3>1 - Your Own Currency</h3>
                             <p>OSIS takes care of all the technical aspects & mints your very own cryptocurrency that is tailored to your business & investment requirements. Accept all major Fiat currencies & Cryptocurrencies, buying your token is as easy as buying a shirt for investors. </p>
                         </div>
                     </div>
                 </div>
                 <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                     <div class="col pl-md-5 order-md-0 order-1">
                         <div class="benefits_box_content">
                             <h3>2 - Publicly Traded Brand</h3>
                             <p>Depart from traditional corporate culture & systems. Emerge as a PTB listed on decentralized exchanges globally. Become tradable like Apple Stock. You are now a netizen, no longer defined by nationality or boxed within borders. You are unlimited. You define your brand. </p>
                         </div>
                     </div>
                     <div class="col-md-auto">
                         <div class="benefits_img">
                             <img src="website/assets/images/become-a-ptb/Icon-2.png" alt="">
                         </div>
                     </div>
                 </div>
                 <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                     <div class="col-md-auto">
                         <div class="benefits_img">
                             <img src="website/assets/images/become-a-ptb/Icon-3.png" alt="">
                         </div>
                     </div>
                     <div class="col">
                         <div class="benefits_box_content">
                             <h3>3 - You Set the Rules</h3>
                             <p>You have complete control over how tokens are used, benefits investors receive & how it is distributed. No more giving away all your equity & ownership to greedy investors who only care about profit. Your cryptocurrency presents a unique opportunity to allow the people who support you to become your financial partners. </p>
                         </div>
                     </div>
                 </div>
                 <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                     <div class="col pl-md-5 order-md-0 order-1">
                         <div class="benefits_box_content">
                             <h3>4 - Be the First</h3>
                             <p>Whether youâ€™re a startup or a public figure, the people who support you are yearning for ways to get more involved. Elevate to the status of a Bitcoin or Google level brand by offering this first-of-a-kind opportunity to supporters; allowing everyone to benefit through the journey. </p>
                         </div>
                     </div>
                     <div class="col-md-auto">
                         <div class="benefits_img">
                             <img src="website/assets/images/become-a-ptb/Icon-4.png" alt="">
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="token_lizestion py-md-5 pt-5 pb-4">
     <div class="container py-lg-5 py-md-4 pt-4">
         <div class="row align-items-center">
             <div class="col-md-5 mb-md-0 mb-5">
                 <div class="token_lizestion_img">
                     <img src="website/assets/images/become-a-ptb/token.png" alt="">
                 </div>
             </div>
             <div class="col-md-7">
                 <div class="token_lizestion_content text-md-left text-center">
                     <h2>Why Tokenization?</h2>
                     <p>Tokenization is technology that allows you to split the ownership of a business, intellectual property, or any kind of asset into a fractional number of pieces (tokens); like shares of a company. Tokenization enables us to democratize investing, and allow anyone with a business idea to be supported by the global community. </p>
                     <a href="#" class="comman_btns mt-3">BUY OSIS</a>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="solutions same_bg py-md-5 py-4">
     <div class="container py-lg-5">
         <div class="row">
             <div class="col-12 sections_header text-center mb-5">
                 <h2>Invest with Trust</h2>
             </div>
         </div>
         <div class="row solutions_outer mt-lg-3">
             <div class="col-md-4 my-md-0 my-4">
                 <div class="solutions_box text-center">
                     <span class="img_part">
                         <img src="website/assets/images/become-a-ptb/trust-1.png" alt="">
                     </span>
                     <h4 class="mb-0 mt-lg-4 mt-md-3 mt-3">Legally Complaint <br> Tokens</h4>
                 </div>
             </div>
             <div class="col-md-4 my-md-0 my-4">
                 <div class="solutions_box text-center">
                     <span class="img_part">
                         <img src="website/assets/images/become-a-ptb/trust-2.png" alt="">
                     </span>
                     <h4 class="mb-0 mt-lg-4 mt-md-3 mt-3">Protected Funds</h4>
                 </div>
             </div>
             <div class="col-md-4 my-md-0 my-4">
                 <div class="solutions_box text-center">
                     <span class="img_part">
                         <img src="website/assets/images/become-a-ptb/trust-3.png" alt="">
                     </span>
                     <h4 class="mb-0 mt-lg-4 mt-md-3 mt-3">Secured by SSL</h4>
                 </div>
             </div>
         </div>
         <div class="row mt-lg-5 mt-md-4 mt-3">
             <div class="col-12 text-center">
                 <a href="#" class="comman_btns mt-3">INVEST NOW</a>
             </div>
         </div>
     </div>
 </section>

 <section class="partners_support same_bg py-md-5 pt-5 pb-4 position-relative">
     <div class="container py-lg-5 py-md-4 pt-4">
         <div class="row align-items-center">
             <div class="col-md-6 mb-md-0 mb-5">
                 <div class="token_lizestion_img">
                     <img src="website/assets/images/documentation/ilustradeck.png" alt="">
                 </div>
             </div>
             <div class="col-md-6">
                 <div class="token_lizestion_content text-md-left text-center">
                     <h2>What do our <br> partners <span>support?</span></h2>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet non praesentium, architecto rem vero mollitia laudantium iusto laborum corrupti voluptatum qui deleniti, inventore ullam delectus voluptas dolor sit amet consectetur adipisicing elit. Amet non praesentium, architecto rem vero mollitia laudantium consectetur ipsam minima fuga!</p>
                     <a href="#" class="comman_btns mt-3">Lorem ipsum</a>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="faq same_bg py-5">
     <div class="container">
         <div class="row">
             <div class="col-12 sections_header text-center mb-5">
                 <h2>Faq</h2>
             </div>
             <div class="col-12 mt-lg-4">
                 <div class="row justify-content-center">
                     <div class="col-lg-11 d-flex flex-column justify-content-center align-items-stretch">
                         <div class="accordion" id="accordionExample">
                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingOne">
                                     <button class="accordion-button" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                         Who can invest through OSIS?
                                     </button>
                                 </h2>
                                 <div id="collapseOne" class="accordion-collapse border-0 collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-0 fs-14">Anyone in the world can invest on our platform. We accept all major currencies & cryptocurrencies. Investors can use their debit, credit, or PayPal to make a deposit. There are certain limits to the amount you can invest depending on your country</p>
                                     </div>
                                 </div>
                             </div>
                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingtwo">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapsetwo" aria-expanded="true" aria-controls="collapsetwo">
                                         What is a Token?
                                     </button>
                                 </h2>
                                 <div id="collapsetwo" class="accordion-collapse border-0 collapse" aria-labelledby="headingtwo" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-0 fs-14">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum quibusdam laborum accusamus officia recusandae, voluptates soluta qui? Laboriosam officia, dolores iure commodi est nam eius atque placeat, rerum, impedit cum. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corporis nobis aut, similique enim ratione hic quis? Deserunt soluta eaque velit sapiente illo tenetur nostrum placeat, consectetur obcaecati doloremque impedit accusamus!</p>
                                     </div>
                                 </div>
                             </div>
                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingthree">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapsethree" aria-expanded="true" aria-controls="collapsethree">
                                         Are Security Token Offerings Legal?
                                     </button>
                                 </h2>
                                 <div id="collapsethree" class="accordion-collapse border-0 collapse" aria-labelledby="headingthree" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-0 fs-14">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum quibusdam laborum accusamus officia recusandae, voluptates soluta qui? Laboriosam officia, dolores iure commodi est nam eius atque placeat, rerum, impedit cum. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corporis nobis aut, similique enim ratione hic quis? Deserunt soluta eaque velit sapiente illo tenetur nostrum placeat, consectetur obcaecati doloremque impedit accusamus!</p>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </section>

 @include('Website.footer')