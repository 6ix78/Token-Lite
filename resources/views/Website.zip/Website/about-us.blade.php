 @include('Website.header')

 <section class="comman_banner about-us">
     <div class="container">
         <div class="row align-items-center">
             <div class="col-lg-7 order-lg-0 order-md-1 order-1 pr-lg-5">
                 <div class="comman_banner_content">
                     <h1>About OSIS</h1>
                     <p>OSIS is a blockchain-based currency and investing platform. We give people the power to invest in & earn from anything; be it a business, athlete, artist, real estate, brand, or public figure. OSIS acts as a launchpad for these aforementioned creators, brands, businesses, & assets eligible for investment. </p>
                     <div class="banner_btns mt-md-4 mt-3 pt-xl-2">
                         <a href="https://osis.world/register" class="comman_btns">GET OSIS</a>
                         <a href="become-a-ptb.php" class="comman_btns ml-md-3 ml-2">TOKENIZE YOUR BRAND</a>
                     </div>
                 </div>
             </div>
             <div class="col-lg-5">
                 <div class="banner_img text-center">
                     <img src="website/assets/images/about-us/about_main.png" alt="">
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="founder_company same_bg pb-lg-5">
     <div class="container py-md-5 pt-4 pb-3">
         <div class="row">
             <div class="col-12">
                 <div class="row banner-content">
                     <div class="col-auto text-left">
                         <span class="fw-bold banner-title2  text-left">WHO we are</span>
                         <div class="pt-lg-5">
                         </div>
                     </div>
                     <div class="col text-border pl-0">
                         <span class="d-flex"></span>
                     </div>
                 </div>
                 <div class="row justify-content-center mt-md-5 mt-4">
                     <div class="col-lg-11 px-md-5">
                         <ul class="nav nav-tabs border-0 justify-content-md-between" id="myTab" role="tablist">
                             <li class="nav-item" role="presentation">
                                 <a class="nav-link border-0 active founder_image" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">
                                     <div class="image_border mx-auto">
                                         <img src="website/assets/images/about-us/photochris.png" alt="">
                                     </div>
                                     <div class="name-color name-heading-common">
                                         <span class="d-block pt-md-4 pt-3">
                                             chris <br>goma
                                         </span>
                                     </div>
                                 </a>
                             </li>
                             <li class="nav-item" role="presentation">
                                 <a class="nav-link border-0 founder_image" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">
                                     <div class="image_border mx-auto">
                                         <img src="website/assets/images/about-us/photojalal.png" alt="">
                                     </div>
                                     <div class="name-color name-heading-common">
                                         <span class="d-block pt-md-4 pt-3">
                                             Jalal <br> Ibrahimi
                                         </span>
                                     </div>
                                 </a>
                             </li>
                             <li class="nav-item" role="presentation">
                                 <a class="nav-link border-0 founder_image" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">
                                     <div class="image_border mx-auto">
                                         <img src="website/assets/images/about-us/photovanessa.png" alt="">
                                     </div>
                                     <div class="name-color name-heading-common">
                                         <span class="d-block pt-md-4 pt-3">
                                             Vanessa <br>Stival
                                         </span>
                                     </div>
                                 </a>
                             </li>
                             <li class="nav-item" role="presentation">
                                 <a class="nav-link border-0 founder_image" id="last-tab" data-toggle="tab" href="#last" role="tab" aria-controls="last" aria-selected="false">
                                     <div class="image_border mx-auto">
                                         <img src="website/assets/images/team/photoiftakhar.png" alt="">
                                     </div>
                                     <div class="name-color name-heading-common">
                                         <span class="d-block pt-md-4 pt-3">
                                             Iftakhar <br> Rahmany
                                         </span>
                                     </div>
                                 </a>
                             </li>
                         </ul>
                         <div class="tab-content mt-md-5 mt-3" id="myTabContent">
                             <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                 <div class="row justify-content-md-start justify-content-center">
                                     <div class="col-md-2 text-md-left text-center text-white name-heading-common">
                                         <span class="d-md-block d-inline-block">CEO/</span>
                                         <span class="d-md-block d-inline-block">Founder</span>
                                     </div>
                                     <div class="col text-md-left text-center ceo_text">
                                         <p class="mb-0"> Chris Goma is a daring visionary with an astute understanding of the human psyche,
                                             contributing to his ability to create a harmonious & efficient work environment in every project he
                                             leads. Chris is the mastermind behind OSIS since 2014, laser-focused on shaping this vision of
                                             a more ethical world. What most don&apos;t know is that he is also an artist, producer, actor, and
                                             writer, outside of his traditional corporate activities.</p>
                                     </div>
                                 </div>
                             </div>
                             <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                 <div class="row justify-content-md-start justify-content-center">
                                     <div class="col-md-2 text-md-left text-center text-white name-heading-common">
                                         <span class="d-md-block d-inline-block">COO/</span>
                                         <span class="d-md-block d-inline-block">Founder</span>
                                     </div>
                                     <div class="col text-md-left text-center ceo_text">
                                         <p class="mb-0"> Jalal is a multifaceted executive & highly dedicated businessman. His talents in the
                                             financial sector, combined with his ability to lead & learn quickly has been instrumental in the
                                             development of each company he & Chris Goma have built along the way. Namely, CoinCare, in
                                             which he was able to generate over $50 Million in loans for small businesses in one quarter
                                             without a website. Needless to say, his ability to listen to his team & think critically is essential to
                                             OSIS&#8482; success.</p>
                                     </div>
                                 </div>
                             </div>
                             <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                                 <div class="row justify-content-md-start justify-content-center">
                                     <div class="col-md-2 text-md-left text-center text-white name-heading-common">
                                         <span class="d-md-block d-inline-block">Head /</span>
                                         <span class="d-md-block d-inline-block">of Design</span>
                                     </div>
                                     <div class="col text-md-left text-center ceo_text">
                                     <p class="mb-0">Vanessa is a master of design & the mind behind the visual identity of OSIS. She has over
                                             a decade&apos;s experience in creating aesthetics, shaping user experience, and delivering a brand&apos;s
                                             message through powerful, and nuanced, design. Vanessa is also a part of the CoinCare team
                                             with Chris & Jalal.
                                         </p>
                                     </div>
                                 </div>
                             </div>
                             <div class="tab-pane fade" id="last" role="tabpanel" aria-labelledby="last-tab">
                                 <div class="row justify-content-md-start justify-content-center">
                                     <div class="col-md-2 text-md-left text-center text-white name-heading-common">
                                         <span class="d-md-block d-inline-block">Head /</span>
                                         <span class="d-md-block d-inline-block">of Development</span>
                                     </div>
                                     <div class="col text-md-left text-center ceo_text">
                                     <p class="mb-0">Iftakhar leads OSIS&apos; internal development and has developed apps & software for
                                             Companies such as Rolls Royce, Siemens, Arabian Bemco, Idea Network, UC Bank, and more.
                                             Iftakhar has deep experience in blockchain development & is a full-stack engineer.
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="our_values same_bg py-md-5 pt-5 pb-4">
     <div class="container py-lg-4">
         <div class="row">
             <div class="col-12 sections_header text-center mb-5">
                 <h2>Our Values</h2>
             </div>
         </div>
         <div class="row justify-content-center mx-0">
             <div class="col-lg-11">
                 <div class="row market_outer px-md-5">
                     <div class="col-12 main_box px-md-3 px-0">
                         <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                             <div class="col-md-auto text-center">
                                 <div class="benefits_img">
                                     <img src="website/assets/images/about-us/Icon-1.png" alt="">
                                 </div>
                                 <h3 class="mb-md-0 mb-2 mt-md-3 mt-0">Security</h3>
                             </div>
                             <div class="col">
                                 <div class="benefits_box_content">
                                     <p>Feeling safe & secure with the money you invest & the people/business you support is of high value to us. We will ensure promising ideas & PTBs will be the backbone of our investing platform. </p>
                                 </div>
                             </div>
                         </div>
                         <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                             <div class="col order-md-0 order-1">
                                 <div class="benefits_box_content">
                                 <p>We do not tolerate any fraudulent activity or manipulation of a creator&apos;s token. Day trading is permitted, however, if we discover unrealistic fluctuations or any attempt to gamble with a token, we will immediately ban you from our website. Please invest in things you care for in earnest.</p>
                                 </div>
                             </div>
                             <div class="col-md-auto text-center">
                                 <div class="benefits_img">
                                     <img src="website/assets/images/about-us/Icon-2.png" alt="">
                                 </div>
                                 <h3 class="mb-md-0 mb-2 mt-md-3 mt-2">Respect</h3>
                             </div>
                         </div>
                         <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                             <div class="col-md-auto text-center">
                                 <div class="benefits_img">
                                     <img src="website/assets/images/about-us/Icon-3.png" alt="">
                                 </div>
                                 <h3 class="mb-md-0 mb-2 mt-md-3 mt-2">Transparency</h3>
                             </div>
                             <div class="col">
                                 <div class="benefits_box_content">

                                     <p>We will always notify our society of the good bad & ugly sides to our journey. We believe honesty is key to holding a healthy relationship with you all. We aim to uphold Our terms & conditions, along with our set of values. They will act as a sort of constitution to abide by & for all of us.</p>
                                 </div>
                             </div>
                         </div>
                         <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                             <div class="col order-md-0 order-1">
                                 <div class="benefits_box_content">

                                     <p>The word & act of love is highly unappreciated & taken for granted. In OSIS, we believe that Love is a fundamental force in nature that must be appreciated & encouraged. When a person finds something to love in our society, whether it be a product, or public figure or brand or business, we encourage our users to show appreciation in whatever way is naturally expressed. Leave fear at the door. Let&apos;s use love as a blessed weapon for expansion. </p>
                                 </div>
                             </div>
                             <div class="col-md-auto text-center">
                                 <div class="benefits_img">
                                     <img src="website/assets/images/about-us/Icon-4.png" alt="">
                                 </div>
                                 <h3 class="mb-md-0 mb-2 mt-md-3 mt-2">Love</h3>
                             </div>
                         </div>
                         <div class="row benefits_box align-items-center py-lg-5 py-md-4 py-4 mb-md-0 mb-4">
                             <div class="col-md-auto text-center">
                                 <div class="benefits_img">
                                     <img src="website/assets/images/about-us/Icon-5.png" alt="">
                                 </div>
                                 <h3 class="mb-md-0 mb-2 mt-md-3 mt-2">Abundance</h3>
                             </div>
                             <div class="col">
                                 <div class="benefits_box_content">

                                     <p>OSIS will be a platform with many great ideas, people & businesses. We highly encourage our society to invest in as many people brands & companies they desire. If you have a genuine affinity towards anything or anyone, understand that your dollar, or cent, holds more weight than the dollar without affinity at all.</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="token_lizestion py-md-5 pt-5 pb-4">
     <div class="container py-lg-5">
         <div class="row align-items-center">
             <div class="col-md-5 mb-md-0 mb-5">
                 <div class="token_lizestion_img">
                     <img src="website/assets/images/become-a-ptb/token.png" alt="">
                 </div>
             </div>
             <div class="col-md-7">
                 <div class="token_lizestion_content text-md-left text-center">
                     <h2>Why Tokenization?</h2>
                     <p>Tokenization is technology that allows you to split the ownership of a business, intellectual property, or any kind of asset into a fractional number of pieces (tokens); like shares of a company. Tokenization enables us to democratize investing, and allow anyone with a business idea to be supported by the global community. </p>
                     <a href="https://osis.world/register" class="comman_btns mt-3">BUY OSIS</a>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="faq same_bg py-5">
     <div class="container py-lg-4">
         <div class="row">
             <div class="col-12 sections_header text-center mb-5">
                 <h2>FAQ</h2>
             </div>
             <div class="col-12 mt-lg-4">
                 <div class="row justify-content-center">
                     <div class="col-lg-11 d-flex flex-column justify-content-center align-items-stretch">
                         <div class="accordion" id="accordionExample">
                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingOne">
                                     <button class="accordion-button" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                         Who can invest through OSIS?
                                     </button>
                                 </h2>
                                 <div id="collapseOne" class="accordion-collapse border-0 collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-0 fs-14">Anyone in the world can invest on our platform. We accept all major currencies &
                                             cryptocurrencies. Investors can use their debit, credit, or PayPal to make a deposit.
                                             There are certain limits to the amount you can invest depending on your country.
                                         </p>
                                     </div>
                                 </div>
                             </div>
                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingtwo">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapsetwo" aria-expanded="true" aria-controls="collapsetwo">
                                         What is a Token?
                                     </button>
                                 </h2>
                                 <div id="collapsetwo" class="accordion-collapse border-0 collapse" aria-labelledby="headingtwo" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-0 fs-14">A token is a digital representation of security, right, or utility. A token can represent the share capital of a company, the right to collect a portion of a loan, etc. It is registered on
                                             the blockchain and ensures that all token transactions that occur between people or
                                             entities are recorded.
                                         </p>
                                     </div>
                                 </div>
                             </div>
                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingthree">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapsethree" aria-expanded="true" aria-controls="collapsethree">
                                         Are Security Token Offerings Legal?
                                     </button>
                                 </h2>
                                 <div id="collapsethree" class="accordion-collapse border-0 collapse" aria-labelledby="headingthree" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-0 fs-14">Yes, they are, and they must be compliant with the laws of the country where they are
                                             issued. OSIS studies the legality of each project before making an issuance.
                                         </p>
                                     </div>
                                 </div>
                             </div>

                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingfour">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapsefour" aria-expanded="true" aria-controls="collapsefour">
                                         How do I get started?
                                     </button>
                                 </h2>
                                 <div id="collapsefour" class="accordion-collapse border-0 collapse" aria-labelledby="headingfour" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-0 fs-14">Create an account in 1 minute to access the platform by <a class="text-white" target="_blank" href="https://www.osis.world/login">going here</a>
                                         </p>
                                     </div>
                                 </div>
                             </div>

                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingfive">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapsefive" aria-expanded="true" aria-controls="collapsefive">
                                         How do I earn money on this platform?
                                     </button>
                                 </h2>
                                 <div id="collapsefive" class="accordion-collapse border-0 collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-0 fs-14">When you invest through OSIS, you can earn money in two major ways
                                         </p>
                                         <ul class="mt-3">
                                             <li>
                                                 <p class="mb-0 fs-14">1. Your tokens go up in price as the Publicly Traded Brand grows & garners a
                                                     higher valuation. You are free to sell your tokens on the OSIS market or other
                                                     decentralized exchanges for a profit.
                                                 </p>
                                             </li>
                                             <li>
                                                 <p class="mb-0 fs-14">2. If the Publicly Traded Brand you invested into issues dividends, then you will
                                                     share in the profits.
                                                 </p>
                                             </li>
                                         </ul>
                                     </div>
                                 </div>
                             </div>

                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingsix">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapsesix" aria-expanded="true" aria-controls="collapsesix">
                                         What is a PTB?
                                     </button>
                                 </h2>
                                 <div id="collapsesix" class="accordion-collapse border-0 collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-3 fs-14">A Publicly Traded Brand (PTB) is similar to a publicly-traded company on the stock
                                             market, like Apple, Google, or Tesla. You can create your own PTB using the Apotheosis
                                             Platform. We mint your brandâ€™s cryptocurrency which is a completely unique token on
                                             the global blockchain; once we list your crypto on the open market, your brand is more
                                             accessible than buying into a Fortune 500 company.
                                         </p>
                                         <p class="mb-0 fs-14">Being actively traded on a public exchange, your brand & token have unlimited upside &
                                             will grow as you grow. This concept is able to capture the emotional quality of your
                                             business, brand, and self.

                                         </p>
                                     </div>
                                 </div>
                             </div>


                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingseven">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapseseven" aria-expanded="true" aria-controls="collapseseven">
                                         How does it work?
                                     </button>
                                 </h2>
                                 <div id="collapseseven" class="accordion-collapse border-0 collapse" aria-labelledby="headingseven" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-3 fs-14">The Apotheosis Platform is built on a secure blockchain network, some call it Internet
                                             3.0. People, brands & companies can essentially tokenize their business with our
                                             technology. This means they can take something (anything) and split its ownership into a
                                             finite number of tokens; similar to shares in a company.
                                         </p>
                                         <p class="mb-3 fs-14">Now, take a house for example. Normally, one or a few people purchase a house & it
                                             costs them hundreds of thousands. With tokenization, the ownership of this house can
                                             be split into thousands of pieces, be sold to thousands of buyers, and each person
                                             would own a piece of real estate for only a few hundred dollars. These buyers can then
                                             benefit from the rental income the house generates and are also free to sell their piece
                                             at any time on the open market.
                                         </p>
                                         <p class="mb-3 fs-14">The same is true for a business. Split your company into thousands of pieces, allow
                                             investors to come in at a low price, and get access to capital faster from an international
                                             investment pool. All of this is done securely through the blockchain; as security &
                                             legitimacy is the foundation of the technology. As an investor, you truly own a share of
                                             the house and the business you buy into. As a seller, you receive real dollars in
                                             exchange for tokenized pieces of your business or assets.
                                         </p>
                                     </div>
                                 </div>
                             </div>

                             <div class="accordion-item mb-lg-4 mb-md-3 mb-3">
                                 <h2 class="accordion-header" id="headingeight">
                                     <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapseeight" aria-expanded="true" aria-controls="collapseeight">
                                         Why should I invest in OSIS?
                                     </button>
                                 </h2>
                                 <div id="collapseeight" class="accordion-collapse border-0 collapse" aria-labelledby="headingthree" data-parent="#accordionExample">
                                     <div class="accordion-body border-0">
                                         <p class="mb-3 fs-14">1. An investment into the initial OSIS platform is an investment into every possibility that can come from it. This means every brilliant person, brand, business, real estate, fine
                                             artwork, idea, etcâ€¦ Every single Publicly Traded Brand that people create here, we
                                             capture that value in the original platformâ€™s token.
                                         </p>
                                         <p class="mb-3 fs-14">This is like investing in Coca-Cola before it expanded to acquire Mountain Dew & the
                                             hundreds of other famous beverages we all enjoy. The sum total value of all these other
                                             beverages is captured within the Coca-Cola brand and divided into the net worths of its
                                             investors
                                         </p>
                                         <p class="mb-3 fs-14">2. You are investing in a movement to create a free and fair global economy. This
                                             platform is a first of its kind, liberating people from a system that does not value them or
                                             what society truly wants this world to become. Apotheosis is raising funds to create the
                                             technology to make this a reality & give everyone the means to create their own Publicly
                                             Traded Branded.
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <section class="solutions same_bg py-md-5 pt-0 pb-5">
     <div class="container py-lg-4">
         <div class="row">
             <div class="col-12 sections_header text-center mb-5">
                 <h2>Invest with Trust</h2>
             </div>
         </div>
         <div class="row solutions_outer mt-lg-3">
             <div class="col-md-4 my-md-0 my-4">
                 <div class="solutions_box text-center">
                     <span class="img_part">
                         <img src="website/assets/images/become-a-ptb/trust-1.png" alt="">
                     </span>
                     <h4 class="mb-0 mt-lg-4 mt-md-3 mt-3">Legally Complaint <br> Tokens</h4>
                 </div>
             </div>
             <div class="col-md-4 my-md-0 my-4">
                 <div class="solutions_box text-center">
                     <span class="img_part">
                         <img src="website/assets/images/become-a-ptb/trust-2.png" alt="">
                     </span>
                     <h4 class="mb-0 mt-lg-4 mt-md-3 mt-3">Protected Funds</h4>
                 </div>
             </div>
             <div class="col-md-4 my-md-0 my-4">
                 <div class="solutions_box text-center">
                     <span class="img_part">
                         <img src="website/assets/images/become-a-ptb/trust-3.png" alt="">
                     </span>
                     <h4 class="mb-0 mt-lg-4 mt-md-3 mt-3">Secured by SSL</h4>
                 </div>
             </div>
         </div>
         <div class="row mt-lg-5 mt-md-4 mt-3">
             <div class="col-12 text-center">
                 <a href="https://osis.world/register" class="comman_btns mt-3">INVEST NOW</a>
             </div>
         </div>
     </div>
 </section>

 @include('Website.footer')